/*
<script src="https://cdnjs.cloudflare.com/ajax/libs/babel-core/5.8.29/browser.min.js"></script>
*/

var criarDeNome = function(primeiroNome="Matheus", ultimoNome="Alves") {
    console.log(primeiroNome + " " + ultimoNome);  
};
criarDeNome();  